---
name: voz
description: Faz a IA escrever com a sua voz porque a sua voz está escrita, e tira os padrões que denunciam texto de IA. Usar antes de qualquer copy, legenda, e-mail, roteiro ou página, e sempre que pedirem "tira a cara de IA disso", "humaniza", "não parece eu".
---

<!-- A FORMA (copie esta anatomia, troque o conteúdo pelo seu)
  1. description  = o gatilho. Quando a IA deve puxar isto sozinha.
  2. A cicatriz   = o erro real que te custou dinheiro ou tempo. Com número.
  3. O procedimento = os passos, na ordem, específicos o bastante para executar.
  4. As armadilhas = o que parece certo e falha. Ninguém escreve essa parte.
  5. O checklist  = como saber que terminou.
  A cicatriz aqui é minha. Troque pela sua: é ela que faz a skill valer.
-->

# Voz

## A cicatriz

Eu publiquei um post que a IA escreveu e três pessoas me disseram, no mesmo dia,
que tinha ficado com cara de IA. Nenhuma soube apontar onde. O texto estava
correto, bem argumentado e afiado.

Fui atrás e o problema estava na assinatura do estilo: negação contrastiva em
quatro frases, três travessões e um aforismo de fechamento que serviria para
qualquer assunto. A IA escreve como **todo mundo**, e o seu público te segue
porque você não é todo mundo.

E tem um detalhe que quase ninguém percebe: quando você "humaniza" um texto de
IA, o que costuma acontecer é trocar uma voz genérica por **outra** voz
genérica. O alvo é soar como **você**, que é bem mais estreito do que soar humano.

## Parte 1: escrever a voz uma vez

Crie um `VOZ.md` na raiz do projeto. É o arquivo que a IA lê antes de escrever
qualquer coisa. Mínimo viável:

```markdown
# Voz

## Quem fala
Uma frase: quem é, para quem fala, de que lugar.

## Como fala
- Frase curta. Ponto final resolve.
- Primeira pessoa, sem plural corporativo.
- Número real em vez de adjetivo ("aumentou muito" → "de 12 para 41").

## Palavras que eu uso
(dez palavras e expressões que aparecem de verdade na sua fala)

## Palavras que eu NUNCA uso
(as que te fazem revirar os olhos: "jornada", "destravar", "elevar", "curadoria")

## Como eu abro
(três aberturas suas de verdade, copiadas de textos seus)

## Como eu fecho
(três fechos seus de verdade)

## Trechos meus, colados na íntegra
(três parágrafos escritos por você, sem edição. É a parte que mais funciona.)
```

**Como preencher sem inventar:** pegue os seus 10 textos com melhor desempenho
e extraia dali. Não descreva como você gostaria de soar. Extraia como você soa.
Se você tem áudio, transcreva e use a transcrição: a sua voz falada é mais
sua que a escrita.

## Parte 2: os padrões que denunciam

Corte na revisão, sem exceção:

1. **Negação contrastiva.** "Não é X, é Y." É o padrão número um. Uma vez pode
   passar; duas na mesma peça e o texto inteiro cheira a IA. Escreva a
   afirmação sozinha.
2. **Travessão como respiração.** Vírgula, ponto, dois-pontos ou parênteses
   resolvem. Se um travessão for mesmo necessário, que seja um na peça inteira.
3. **Tom apocalíptico.** "Morreu", "acabou", "vai desaparecer". Soa forçado e
   convida a discordância barata. Troque por "trocou de embalagem", "ficou
   lento", "vem perdendo".
4. **Tricolon.** Três itens paralelos e ritmados em toda frase importante.
5. **Aforismo de fechamento.** Aquela última linha curta e sábia que não diz
   nada. Se ela pode fechar qualquer texto sobre qualquer assunto, apague.
6. **Adjetivo no lugar de número.** "Muito", "enorme", "significativo".
7. **Elogio à pergunta.** "Ótima pergunta", "excelente ponto".
8. **Simetria perfeita.** Todos os bullets do mesmo tamanho, todos os parágrafos
   com três frases. Texto humano é irregular.

## As armadilhas (a do template é a que mais volta)

Depois de limpar o texto, cuidado com o **molde**. Se o seu template de post tem
um campo chamado "frase de impacto" ou "frase-chave", ele vai puxar aforismo de
volta, toda vez, por mais limpa que a copy estivesse. O padrão volta pela
estrutura, não pelo texto.

**Regra:** quando um padrão reaparecer duas vezes seguidas, o conserto é no
molde.

## Como usar

- **Antes de escrever:** leia o `VOZ.md` inteiro.
- **Depois de escrever:** passe a lista dos 8 padrões, um por um, e mostre o que
  foi cortado.
- **Edição mínima efetiva.** Frase humana boa fica como está. Reescrever tudo é
  como se perde a voz.
- **Nunca invente fato para melhorar o ritmo.** Preserve os números, os nomes e
  as ressalvas exatamente como estavam.

## Checklist

- [ ] O `VOZ.md` existe e tem trechos reais, não descrição
- [ ] Zero negação contrastiva
- [ ] Zero travessão (ou no máximo um)
- [ ] Nenhum fecho que serviria para qualquer assunto
- [ ] Todo número que estava no original continua lá, igual
- [ ] Se o padrão voltou pela segunda vez, o molde foi corrigido
