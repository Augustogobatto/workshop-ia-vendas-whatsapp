---
name: decisao
description: Passa qualquer aposta de dinheiro pelo checklist Buffett/Munger antes de decidir (aporte, sócio, projeto novo, compra grande, aumentar posição). Usar sempre que aparecer "devo entrar em X?", "vale investir?", "sociedade", ou entrada de dinheiro em algo novo. Devolve o checklist preenchido e cobra a regra de saída antes da entrada.
---

<!-- A FORMA (copie esta anatomia, troque o conteúdo pelo seu)
  1. description  = o gatilho. Quando a IA deve puxar isto sozinha.
  2. A cicatriz   = o erro real que te custou dinheiro ou tempo. Com número.
  3. O procedimento = os passos, na ordem, específicos o bastante para executar.
  4. As armadilhas = o que parece certo e falha. Ninguém escreve essa parte.
  5. O checklist  = como saber que terminou.
  A cicatriz aqui é minha. Troque pela sua: é ela que faz a skill valer.
-->

# Decisão

## A cicatriz

Uma aposta minha entrou com a regra de saída escrita antes do primeiro real:
teto de gasto e **dois dias de trabalho** como prazo de kill. O produto ficou
pronto em **três dias**. A burocracia do terceiro que precisava aprovar consumiu
**quinze**, com cinco pedidos idênticos que falharam do mesmo jeito.

Sem a regra escrita antes, aquilo viraria o que a maioria das minhas apostas
antigas virou: viva-morta, sem consumir mais dinheiro e consumindo atenção
todo dia. Com a regra, o estouro do prazo me obrigou a olhar e decidir. E a
investigação do estouro achou a causa real, que cinco tentativas repetidas
nunca achariam.

Aposta boa se define antes de entrar. Dentro dela, todo mundo se acha racional.

## O procedimento (as regras, na ordem em que pesam)

**Antes de apostar**

1. **Círculo de competência.** Você sabe julgar isso melhor que a média? Risco
   vem de não saber o que se está fazendo. Fora do círculo, a resposta padrão
   é não.
2. **Entender o motor.** Explicar em um parágrafo quem paga, por quê, e qual a
   vantagem defensável. Se precisa de palavra da moda pra explicar, reprova.
3. **Inversão.** Nomear as três mortes mais prováveis da aposta. Quem não
   consegue nomear as três ainda não entendeu a aposta.
4. **Pessoas.** Bom negócio com gente ruim vira negócio ruim. Em posição
   minoritária você está comprando o operador, muito mais do que a tese.

**Tamanho**

5. **Dimensionar pelo pior caso.** A pergunta é "se zerar, a minha vida muda?",
   em porcentagem do patrimônio, com o número na mesa.
6. **Reserva é intocável.** Nunca arriscar o que você tem e precisa pelo que
   você quer e dispensa. Aposta se faz com excedente.
7. **Cartão de vinte furos.** Trate como se a vida inteira coubesse em vinte
   apostas. Quase tudo merece um não.
8. **Não existe strike por deixar passar.** A ansiedade de "fazer algo" é o
   estado em que as piores apostas entram.

**Julgamento**

9. **Preço e valor são coisas diferentes**, e a sua estimativa VAI estar
   errada: exija margem de segurança que sobreviva ao erro.
10. **Custo de oportunidade é a régua de tudo.** Compare com a renda fixa sem
    risco e com investir no seu próprio negócio, que é o seu círculo.

**A regra de saída, ANTES de entrar**

Teto de dinheiro **e** prazo ou marco de kill, os dois por escrito. Teto sem
prazo deixa a aposta viva-morta. E registre onde você reencontra: a regra que
não está escrita se renegocia sozinha na cabeça.

## As armadilhas

1. **Ansiedade entre picos de receita.** O momento em que mais dá vontade de
   apostar é o momento de pior julgamento. Cheque o item 8 em dobro quando o
   caixa estiver ansioso.
2. **Aposta que depende de aprovação de terceiro.** O prazo de kill conta só o
   SEU tempo de trabalho; a dependência externa vira um checkpoint separado,
   com dono. Senão o kill pune você por atraso que é do outro.
3. **Tentativa repetida como progresso.** Duas tentativas idênticas que falham
   igual não geram informação nova. Pare e troque de canal.
4. **Diversificar dentro do círculo, concentrar fora.** É o contrário:
   diversificação é proteção contra ignorância (legítima fora do círculo);
   dentro dele, odds claramente a favor pedem concentração.

## Checklist

- [ ] As dez perguntas respondidas por escrito, com número onde couber
- [ ] O pior caso dimensionado em % do patrimônio
- [ ] As três mortes mais prováveis nomeadas
- [ ] Comparado com renda fixa e com o próprio negócio
- [ ] Teto E prazo de kill escritos antes do primeiro real
- [ ] Registro guardado onde a próxima conversa sobre a aposta reencontra

A base é Warren Buffett e Charlie Munger (cartas da Berkshire e o almanaque do
Munger). O checklist e a regra de saída são a minha aplicação.
