---
name: rastreio
description: Audita se a origem da venda sobrevive da página até o checkout, e escreve o código que faz sobreviver. Usar ao criar ou revisar landing page que manda pra Hotmart, Kiwify, Eduzz ou checkout externo, e sempre que aparecer "venda sem rastreio", "sck vazio", "não sei de qual criativo veio", "UTM não chega".
---

<!-- A FORMA (copie esta anatomia, troque o conteúdo pelo seu)
  1. description  = o gatilho. Quando a IA deve puxar isto sozinha.
  2. A cicatriz   = o erro real que te custou dinheiro ou tempo. Com número.
  3. O procedimento = os passos, na ordem, específicos o bastante para executar.
  4. As armadilhas = o que parece certo e não é. É a parte que ninguém escreve.
  5. O checklist  = como saber que terminou.
  A cicatriz aqui é minha. Troque pela sua: é ela que faz a skill valer.
-->

# Rastreio

## A cicatriz

Auditei uma conta de infoproduto para responder uma pergunta simples: a IA de
atendimento vendeu, ou a gente só não traqueou?

Não deu para responder. A tag de origem estava vazia nas **1.704 compras da
conta**, desde a primeira. Não era o canal sob suspeita: era a conta inteira.

O pipeline estava certo. O webhook mapeava o campo, o banco não apagava a coluna.
A tag chegava vazia porque a landing page **não vendia**: o botão abria um popup
de captura de e-mail e mandava para uma página de obrigado. A compra acontecia
depois, por outro caminho, e a origem morria ali. Para todos os canais.

Sem rastreio, "de onde veio essa venda" não tem resposta, e cada pessoa da mesa
defende a própria versão com o mesmo grau de certeza.

## A regra que resolve a discussão

**Sem tag, a venda não é de ninguém.**

Em qualquer métrica atribuída (CPV, ROAS, venda por canal):

1. O numerador só aceita item com **prova positiva** (a tag está lá).
2. O balde "sem tag" sai **visível** no relatório, como margem de erro.
3. Quando o sem-tag cresce, a ação é **consertar a marcação na origem**, nunca
   afrouxar o critério. Régua leniente esconde justamente o defeito que ela
   deveria expor.
4. Leniência só no histórico, no período em que a marcação comprovadamente não
   funcionava, e isso escrito no relatório.

Par de leitura para quem compara com o painel do anunciante: **a plataforma de
anúncio é teto, a sua tag é piso, a verdade anda entre os dois.**

## O padrão de código

Na landing, capture os parâmetros de origem e **carregue-os até o link de
pagamento**. Não confie no gateway para herdar nada.

```js
// 1. Guarde a origem assim que a pessoa chega (o clique pode vir depois)
const P = new URLSearchParams(location.search);
const CAMPOS = ['utm_source','utm_medium','utm_campaign','utm_content','utm_term','sck','fbclid','gclid'];
CAMPOS.forEach(k => { const v = P.get(k); if (v) sessionStorage.setItem(k, v); });

// 2. Enriqueça TODO link de checkout, sempre a partir do href real do elemento
function enriquecer(href) {
  const u = new URL(href);
  CAMPOS.forEach(k => {
    const v = P.get(k) || sessionStorage.getItem(k);
    if (v && !u.searchParams.has(k)) u.searchParams.set(k, v);
  });
  // sck é o campo que a Hotmart devolve no webhook; monte-o você, não deixe vazio
  if (!u.searchParams.get('sck')) {
    const s = sessionStorage.getItem('utm_source') || 'direto';
    const c = sessionStorage.getItem('utm_campaign') || 'sem_campanha';
    u.searchParams.set('sck', `${s}_${c}`.slice(0, 60));
  }
  return u.toString();
}
document.querySelectorAll('a[href*="pay."],a[href*="checkout"]').forEach(a => { a.href = enriquecer(a.href); });
```

## As armadilhas (os dois bugs que já custaram lançamento)

**1. O modal que ignora o link enriquecido.** A página enriquece os `<a>` no
carregamento, mas o botão principal abre um modal de captura e, no submit, faz
`window.location = LINK_FIXO` com uma constante escrita à mão. O enriquecimento
não passa por ali. **Todo caminho até o checkout tem que passar pela mesma
função `enriquecer()`**, inclusive o do modal, o do botão flutuante, o do
rodapé e o do "voltar ao topo".

**2. O `+55` que come o DDD.** Campo de telefone com máscara que já vem com
`+55` preenchido, mais autopreenchimento do navegador, e o número chega no
gateway sem os dois primeiros dígitos. Isso quebra a conciliação por telefone,
que costuma ser o único jeito de casar venda com lead quando o e-mail difere.
Teste com autofill ligado, num celular real, e confira o valor que sai no POST.

## O teste de 2 minutos (fazer sempre antes de subir)

1. Abrir a URL **limpa**, em aba anônima. Não a variante com query que você usou
   para desenvolver: a URL limpa é a que o público recebe.
2. Abrir de novo com `?utm_source=teste&utm_campaign=teste123`.
3. Clicar em **cada** caminho de compra e olhar a barra de endereço do checkout:
   os parâmetros estão lá?
4. Comprar de verdade, com valor mínimo ou cupom, e conferir se a tag chegou no
   webhook / no relatório de vendas. **Só o dinheiro real prova esse elo.**
5. Rodar o mesmo teste no celular, com autofill ligado.

## Checklist de auditoria de conta existente

- [ ] Que porcentagem das vendas dos últimos 30 dias tem tag? (se for ~0%, o
      problema é estrutural, não do canal sob suspeita)
- [ ] A landing **vende** ou **captura**? Se captura, a origem morre no popup
- [ ] Os links de página (não só os de checkout) carregam a tag?
- [ ] Existe algum caminho de compra com link escrito à mão no código?
- [ ] O relatório mostra o balde "sem tag" como linha visível?
