---
name: docs-first
description: Busca a documentação oficial antes de hipotetizar sobre comportamento de plataforma de terceiro (Meta, Instagram, Stripe, Hotmart, Supabase, Telegram...). Disparar quando o sintoma envolver serviço externo, "parece bug da plataforma", API que responde 200 sem o efeito aparecer, ou coisa que funciona pra um usuário e falha pra outro.
---

<!-- A FORMA (copie esta anatomia, troque o conteúdo pelo seu)
  1. description  = o gatilho. Quando a IA deve puxar isto sozinha.
  2. A cicatriz   = o erro real que te custou dinheiro ou tempo. Com número.
  3. O procedimento = os passos, na ordem, específicos o bastante para executar.
  4. As armadilhas = o que parece certo e falha. Ninguém escreve essa parte.
  5. O checklist  = como saber que terminou.
  A cicatriz aqui é minha. Troque pela sua: é ela que faz a skill valer.
-->

# Docs first

## A cicatriz

Perdi horas de um dia hipotetizando por que a DM automática do meu funil "não
chegava": limite de envio? conta de teste? revisão do app? Instagram bugado?

A resposta estava escrita na documentação da Meta. Mensagem automática para quem
**não segue** a conta cai na pasta Solicitações, sem notificação. Chegava em
todas. Uma busca de **dois minutos** matava a investigação inteira.

A frase que virou regra aqui dentro: se for na tentativa e erro, a gente passa a
vida descobrindo o que está documentado.

## O procedimento

1. **Formule a pergunta como o dev da plataforma escreveria**, em inglês.
   "instagram private reply delivery folder follower" acha; "por que minha DM
   não chega" se afoga.
2. **Fonte oficial primeiro.** Meta: developers.facebook.com/docs · Stripe:
   docs.stripe.com · Supabase: supabase.com/docs · Hotmart:
   developers.hotmart.com · Telegram: core.telegram.org. Blog de terceiro é o
   último recurso, e nunca a prova.
3. **Colha a citação textual**, com a frase da doc na mão. Comportamento de
   plataforma se afirma com quote, e paráfrase de doc é onde o erro entra.
4. **Cruze a citação com os fatos observados.** Só o que a doc não explicar
   vira hipótese, e sai rotulada como hipótese.
5. **Salve a regra permanente** num arquivo de referência seu, com o link,
   para a próxima vez nem precisar buscar.

## As armadilhas (os sinais de que era pra ter aberto a doc)

1. Qualquer frase sua começando com "provavelmente o Instagram/Stripe/...".
2. **A API respondeu 200 e o efeito não apareceu.** Sucesso de entrega e
   sucesso de exibição são contratos diferentes, e a diferença está documentada.
3. **Funciona pra um usuário e falha pra outro.** Quase sempre é uma condição
   documentada do usuário (segue ou não segue, opt-in, região, plano), e não
   instabilidade.
4. **"Deve ser lentidão / bug da plataforma."** Plataformas grandes quebram
   bem menos do que a nossa leitura delas.
5. Testar de novo a mesma coisa esperando resultado diferente, sem nenhuma
   informação nova entre as tentativas.

## Checklist

- [ ] A pergunta foi formulada em inglês, como um dev escreveria
- [ ] A fonte aberta é a oficial, com a citação textual colhida
- [ ] O que a doc explica foi separado do que virou hipótese
- [ ] Toda hipótese está rotulada como hipótese
- [ ] A regra permanente foi salva com o link
