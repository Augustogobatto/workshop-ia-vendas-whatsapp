---
name: vespera
description: Checklist de véspera de lançamento. Responde "estamos prontos?" com o que foi RODADO, nunca com feeling. Usar quando faltar pouco para abrir carrinho, subir vídeo de venda, ligar tráfego, ou sempre que alguém perguntar se está tudo pronto.
---

<!-- A FORMA (copie esta anatomia, troque o conteúdo pelo seu)
  1. description  = o gatilho. Quando a IA deve puxar isto sozinha.
  2. A cicatriz   = o erro real que te custou dinheiro ou tempo. Com número.
  3. O procedimento = os passos, na ordem, específicos o bastante para executar.
  4. As armadilhas = o que parece certo e não é. É a parte que ninguém escreve.
  5. O checklist  = como saber que terminou.
  A cicatriz aqui é minha. Troque pela sua: é ela que faz a skill valer.
-->

# Véspera

## A cicatriz

Véspera de um lançamento, a pergunta foi "estamos prontos?". A checagem achou
três coisas. **Nenhuma das três aparecia em teste de código, e as três teriam
estragado o lançamento:**

1. **A compra nunca tinha rodado com dinheiro real.** O webhook de
   pagamento → liberação de acesso ia estrear com o cliente do vídeo.
2. **O e-mail de confirmação estava limitado a 30 por hora** no provedor. O
   inscrito número 31 da primeira hora não receberia nada. Invisível até o pico.
3. **O checkout mostrava a marca de OUTRA empresa** (conta de gateway
   compartilhada). Atrito de conversão no pior lugar possível, e invisível para
   quem só testa o próprio produto.

**Lançamento estressa exatamente os elos que o desenvolvimento nunca exercita:**
pagamento real, volume, e o que o cliente vê na hora de pagar.

## O procedimento

### 1. Uma transação real, ponta a ponta

Não é teste em sandbox. É compra com cartão de verdade, de preferência do
próprio dono, no valor mínimo ou com cupom. Percorrer: clique → checkout →
pagamento → webhook → acesso liberado → e-mail recebido.

Anotar em qual etapa parou. Se não parou em nenhuma, dizer isso com o ID da
transação.

### 2. Os tetos escondidos, contra o pico esperado

Faça a conta antes: quantas pessoas por hora no pico? Agora compare com:

- rate limit de e-mail do provedor de autenticação (o padrão costuma ser
  ridiculamente baixo)
- teto do provedor de SMTP / envio (é outra camada, some com a de cima)
- limite de requisição da API que o funil usa
- teto de mensagem do canal de atendimento
- teto de assento / vaga da plataforma de entrega

Cada um vira uma linha com **número contra número**, não com "deve dar".

### 3. A tela de pagamento com olhos de cliente

Abrir o checkout **em aba anônima, pela URL limpa**, num celular:

- Qual marca aparece? É a sua?
- O valor está certo? O parcelamento está certo?
- O desconto da campanha entra **sozinho**, ou depende da pessoa digitar? (nunca
  confie que ela digita: a sessão de checkout tem que nascer com o desconto)
- O idioma e a moeda estão certos?
- O produto tem o nome que foi anunciado?

### 4. Os becos sem saída

Toda tela de espera, erro ou "aguarde" precisa de uma **válvula humana**: um
link pequeno de "preciso de ajuda" com WhatsApp e mensagem pré-preenchida.
Usuário travado sem saída é venda perdida em silêncio, e você nunca fica sabendo.

### 5. O rastreio

Rodar o teste da skill `rastreio`. Lançamento sem marcação vira briga de versão
depois.

## Como responder "estamos prontos?"

Nunca com "sim". Sempre com uma lista do que foi **rodado**, separando:

```
VERDE   (rodou e passou)
  · transação real: R$1,00, id ch_xxx, acesso liberado em 4s, e-mail em 11s
  · rate limit de e-mail: 300/h contra pico estimado de 120/h

ÂMBAR   (rodou e tem ressalva) — cada um com AÇÃO e DONO
  · SMTP no plano free: teto de 100/dia. AÇÃO: subir plano hoje. DONO: você

VERMELHO (não rodou, ou rodou e falhou)
  · webhook de reembolso nunca exercitado
```

Âmbar sem ação nomeada é verde disfarçado. Se não deu para rodar, o item é
vermelho, não verde.

## Checklist

- [ ] Uma compra real ponta a ponta, com ID
- [ ] Cada teto conhecido comparado com o pico estimado, em número
- [ ] Checkout aberto em anônima, no celular, com olhos de cliente
- [ ] Desconto entrando sozinho
- [ ] Válvula humana em cada beco
- [ ] Rastreio chegando no gateway
- [ ] Resposta entregue como verde/âmbar/vermelho, com ação por âmbar
