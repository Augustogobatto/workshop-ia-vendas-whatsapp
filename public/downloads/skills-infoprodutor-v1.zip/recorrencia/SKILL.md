---
name: recorrencia
description: Audita assinatura que está morrendo em silêncio (inadimplência acumulada, webhook não configurado, plano ou oferta nascendo sozinho, preço que não existe na tabela). Usar quando aparecer "MRR caindo", "churn", "cobrança recorrente", "assinatura", "por que essa pessoa pagou esse valor", ou ao assumir a operação de um produto de recorrência.
---

<!-- A FORMA (copie esta anatomia, troque o conteúdo pelo seu)
  1. description  = o gatilho. Quando a IA deve puxar isto sozinha.
  2. A cicatriz   = o erro real que te custou dinheiro ou tempo. Com número.
  3. O procedimento = os passos, na ordem, específicos o bastante para executar.
  4. As armadilhas = o que parece certo e não é. É a parte que ninguém escreve.
  5. O checklist  = como saber que terminou.
  A cicatriz aqui é minha. Troque pela sua: é ela que faz a skill valer.
-->

# Recorrência

## A cicatriz

Fui olhar a conta de cobrança de uma empresa minha. **R$18.700 em aberto** e
**zero webhooks configurados.**

Não é que a cobrança falhou. É que quando ela falhava ninguém ficava sabendo, e
quando ela era paga ninguém ficava sabendo também. O sistema de cobrança estava
funcionando perfeitamente sozinho, num canto, sem falar com ninguém.

Recorrência não morre de uma vez. Ela vaza. E vaza silenciosa, porque o painel
mostra o total e o total demora meses para cair o suficiente para alguém
perguntar.

## O que auditar (nesta ordem)

### 1. O silêncio: existe webhook?

Para cada gateway (Hotmart, Kiwify, Asaas, Stripe, Eduzz, Guru):

- Existe webhook cadastrado? Aponta para uma URL que responde 200 **hoje**?
- Qual foi a última entrega bem-sucedida? Se foi há semanas, o webhook está
  morto e ninguém percebeu.
- Os eventos de **falha** estão inscritos, não só os de sucesso? Falha de
  cobrança é o evento que mais importa e o que mais gente esquece de assinar.

Sem webhook vivo, todo o resto desta auditoria é arqueologia manual.

### 2. O buraco: quanto está em aberto

Some as cobranças vencidas e não pagas, por idade (0-7 dias, 8-30, 31-90, 90+).

- 0-7 dias é operacional: cartão recusado, resolve com uma mensagem.
- 90+ é decisão: cobra, cancela, ou aceita a perda e limpa a base para o número
  parar de mentir.

Um total grande de "em aberto" sem essa quebra por idade não serve para nada.

### 3. O plano que nasce sozinho

Plataforma de infoproduto cria plano e oferta sem ninguém pedir. Recuperação de
assinatura, retentativa com desconto, plano de retenção: cada um vira um código
novo na sua tabela de preços, com um valor que você nunca definiu.

**Sintoma:** aparece um plano com prefixo estranho, ou uma oferta que não está
na sua lista, cobrando um valor que não existe na sua tabela.

**Como achar:** liste os valores distintos cobrados nos últimos 90 dias e
compare com a sua tabela de preços. Todo valor que não bate vira uma linha de
investigação, com o código do plano e a data da primeira ocorrência.

### 4. O anual dividido por 12

A armadilha mais comum e a mais cara de entender depois. Uma assinatura anual
paga em 12 parcelas aparece no relatório como uma **mensalidade**, com o valor
da parcela. Quem lê o painel conclui que tem um monte de assinante mensal
pagando pouco, e o cálculo de receita mensal recorrente sai errado nos dois
sentidos: infla a contagem de assinantes e desinfla o ticket.

**Regra:** antes de calcular receita recorrente, separe por **ciclo de
cobrança**, não por valor da parcela. Anual parcelado é anual.

### 5. O acesso que não acompanha

Quem cancelou continua com acesso? Quem pagou depois de falhar recuperou o
acesso sozinho? Os dois erros existem, e o segundo é pior: a pessoa paga, não
entra, pede reembolso e você perde a assinatura e a confiança.

Teste os dois caminhos com uma conta de mentira.

## O relatório de saída

```
GATEWAY        webhooks vivos? último evento? eventos de falha inscritos?
EM ABERTO      total, quebrado por idade (0-7 / 8-30 / 31-90 / 90+)
PLANOS         códigos ativos; quais não estão na tabela oficial; desde quando
RECEITA        por ciclo de cobrança (mensal / anual / anual parcelado), separados
ACESSO         cancelado ainda entra? recuperado volta a entrar?
```

Cada linha com número. "Parece ok" não é linha de relatório.

## Checklist

- [ ] Webhook cadastrado, respondendo hoje, com evento de falha inscrito
- [ ] Inadimplência quebrada por idade
- [ ] Todo valor cobrado nos últimos 90 dias existe na sua tabela de preços
- [ ] Receita recorrente calculada por ciclo, com anual parcelado separado
- [ ] Os dois caminhos de acesso testados (cancelou / recuperou)
