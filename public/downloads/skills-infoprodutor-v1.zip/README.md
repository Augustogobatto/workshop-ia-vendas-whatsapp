# 8 skills de infoprodutor

Isto não é um pack de prompts. São oito procedimentos meus, abertos, do jeito
que rodam na minha máquina.

Eu abri para você copiar **a forma**, não o conteúdo. A cicatriz de cada uma é
minha. Sozinha, ela te serve como exemplo. Trocada pela sua, ela vira a skill
mais útil que você tem.

— Augusto Gobatto (@augustogobatto)

---

## O que é uma skill

Uma pasta com um arquivo `SKILL.md` dentro. No topo, um `name` e uma
`description`. Embaixo, o procedimento escrito em português.

A diferença para um prompt salvo não está no arquivo: está em **onde ele mora**.
Prompt mora no seu bloco de notas e depende de você lembrar de colar. Skill mora
no lugar onde a IA procura, é versionada junto com o projeto, e a próxima pessoa
que entrar herda.

A `description` é a parte mais difícil de escrever, porque é ela que decide se a
skill carrega ou não. Escreva com as palavras que **você** usa quando pede a
coisa, não com as palavras que descrevem a coisa. Quando não carregar sozinha,
chame pelo nome: `/gloop`, `/rastreio`.

## Instalação (Claude Code)

```bash
unzip skills-infoprodutor-v1.zip -d ~/.claude/skills/
```

Confira com `/skills` ou abra o Claude Code e faça a pergunta-gatilho, por
exemplo: *"revisa isso antes de eu publicar"* deve puxar a `gloop`.

Para instalar só num projeto, descompacte em `.claude/skills/` na raiz dele.

## Se você não usa Claude Code

O conteúdo é markdown puro, então funciona colado num Project do ChatGPT, numa
Gem do Gemini, ou no topo de uma conversa. Você perde a única coisa que a skill
tem de especial, que é carregar sozinha na hora certa, e passa a depender de
lembrar. É pior, e ainda assim é melhor que nada.

## As oito

**Dinheiro**
| | |
|---|---|
| `vigia` | constrói o vigia que grita quando a venda quebra (não é ele que vigia: ele escreve o que vigia) |
| `rastreio` | faz a origem da venda sobreviver da página até o checkout |
| `recorrencia` | acha a assinatura que está morrendo em silêncio |
| `vespera` | responde "estamos prontos?" com o que foi rodado, nunca com feeling |

**Conteúdo**
| | |
|---|---|
| `filtro` | dá nota na pauta antes de você gravar |
| `voz` | faz a IA escrever com a sua voz, porque a sua voz está escrita |

**Método**
| | |
|---|---|
| `gloop` | crítica adversarial em rodadas até parar de sangrar |
| `fim` | fecha a sessão gravando o que a IA aprendeu |

## Como trocar a cicatriz pela sua

Abra qualquer `SKILL.md`. Depois do cabeçalho tem um bloco comentado com a
anatomia: gatilho, cicatriz, procedimento, armadilhas, checklist.

1. **Ache a sua cicatriz.** Não é um tema, é um episódio: a vez que você perdeu
   dinheiro, tempo ou cliente por causa disso. Se não tem número, não é cicatriz
   ainda, é opinião.
2. **Escreva o procedimento como você faria hoje**, sabendo o que sabe agora.
3. **A parte que vale mais é a das armadilhas**: o que parece certo e não é.
   Ninguém escreve essa parte, e é ela que a IA nunca adivinha.
4. **O checklist é como você sabe que terminou.** Sem ele, a IA para quando
   cansa.

Regra que eu sigo: quando eu explico a mesma coisa pela terceira vez, aquilo
vira skill no mesmo dia.

## Licença

MIT (arquivo `LICENSE`). Use, edite, ensine, venda o serviço que usa isto. Se
publicar uma versão modificada, não diga que é a minha.

Créditos e fontes em `CREDITOS.md`. Versão e mudanças em `CHANGELOG.md`.
