# Changelog

## v1 — 24/08/2026

Primeira versão pública. Oito skills: `vigia`, `rastreio`, `recorrencia`,
`vespera`, `filtro`, `voz`, `gloop`, `fim`.

A versão mais recente está sempre em https://ia.augustogobatto.com/skills
