---
name: fim
description: Ritual de encerramento de sessão. Grava o que a IA aprendeu num arquivo local, atualiza as skills que mudaram, e entrega o resumo com as pendências. Usar quando pedirem "fecha a sessão", "salva tudo", "termina por hoje", ou ao final de qualquer trabalho longo que gerou decisão ou lição.
---

<!-- A FORMA (copie esta anatomia, troque o conteúdo pelo seu)
  1. description  = o gatilho. Quando a IA deve puxar isto sozinha.
  2. A cicatriz   = o erro real que te custou dinheiro ou tempo. Com número.
  3. O procedimento = os passos, na ordem, específicos o bastante para executar.
  4. As armadilhas = o que parece certo e falha. Ninguém escreve essa parte.
  5. O checklist  = como saber que terminou.
  A cicatriz aqui é minha. Troque pela sua: é ela que faz a skill valer.
-->

# Fim

## A cicatriz

Desde janeiro eu perco os primeiros **vinte minutos de toda segunda-feira**
contando de novo pra IA onde as coisas moram, o que já foi tentado e não
funcionou, e qual foi a decisão que eu tomei na semana passada e não quero
rediscutir. Vinte minutos por semana, todas as semanas.

A IA não lembra de nada, e a gente age como se ela lembrasse. O custo não
aparece hoje: aparece amanhã, na reabertura.

A sessão de trabalho produz duas coisas: o resultado, que fica no arquivo, e o
**contexto**, que evapora quando você fecha a janela. Esta skill existe para o
segundo.

## O ritual (nesta ordem)

### 1. Recapitular internamente

O que foi entregue (com caminho, commit, URL ou ID), quais decisões **a pessoa**
tomou, o que se aprendeu, e o que ficou aberto.

### 2. Gravar a memória

Um arquivo por dia em `~/.claude/memoria/AAAA-MM-DD.md` (crie a pasta se não
existir). **Append, nunca sobrescrever:** um dia pode ter várias sessões, e
substituir o arquivo apaga o trabalho da manhã.

```markdown
## [HH:MM] <tema da sessão>

**Entregue:** ... (com caminho/commit/URL)
**Decisões:** ... (o que a pessoa decidiu, nas palavras dela)
**Aprendido:** ... (o que surpreendeu, o que quebrou e por quê)
**Pendente:** ... (o quê, com quem, até quando)
```

O campo que mais paga é **Aprendido**. Entrega você reencontra no git; a
surpresa não fica registrada em lugar nenhum.

### 3. Promover o que é durável

Nem tudo que aconteceu hoje importa em novembro. Promova para um arquivo
permanente só o que passa neste teste: **isso vai ser verdade daqui a três meses
e não está escrito no código?**

- Decisão com motivo → `DECISOES.md` do projeto
- Lição sobre uma ferramenta (a armadilha, o parâmetro, o comportamento
  inesperado) → a skill correspondente, seção nova, com a data
- Fato sobre a pessoa ou o negócio (preferência, restrição, meta) →
  `~/.claude/memoria/PERFIL.md`

**Se a sessão mudou o modo de fazer alguma coisa, a skill correspondente muda
hoje, não "quando der".** Skill que não recebe a lição da semana passada é
documentação errada, e documentação errada custa mais caro que documentação
nenhuma: a IA acredita nela.

### 4. Se surgiu domínio novo e recorrente, criar a skill

Sinal de que chegou a hora: você explicou a mesma coisa pela terceira vez.

### 5. O resumo final

A última mensagem da sessão, para a pessoa ler no celular:

- **Entregue**, em bullets curtos, com caminho ou link
- **Decisões registradas** (para ela conferir se você entendeu certo)
- **Pendências dela**: o quê, com quem, e o que destrava
- **Onde ficou documentado**

Sem parabéns, sem resumo do resumo.

## As armadilhas

1. **Salvar por cima em vez de acrescentar.** Um dia tem várias sessões, e a
   função que "salva a nota do dia" costuma substituir o arquivo inteiro. Você
   perde a manhã para registrar a tarde.
2. **Registrar entrega e chamar de memória.** O que foi entregue está no git. O
   que se perde é a surpresa: o que quebrou, e por quê.
3. **Deixar a lição na sessão em vez de mandar pra skill.** Skill que não recebe
   a lição da semana passada vira documentação errada, e a IA acredita nela.
4. **Promover tudo.** Se todo detalhe do dia virar memória permanente, em um mês
   nada é encontrável. O teste é se ainda será verdade em três meses.

## Como recuperar no dia seguinte

No começo da sessão: leia `~/.claude/memoria/PERFIL.md` e os dois arquivos de
dia mais recentes. É rápido e mata os vinte minutos de reexplicação.

Se o seu ambiente permite instrução permanente (um `CLAUDE.md` na raiz do
projeto, por exemplo), coloque essa leitura lá, para acontecer sozinha.

## Checklist

- [ ] Arquivo do dia gravado por **append**, não por substituição
- [ ] O campo "Aprendido" registra o que surpreendeu ou quebrou
- [ ] Toda lição sobre ferramenta foi para a skill dela, com data
- [ ] Pendência tem dono, além da descrição
- [ ] O resumo cabe na tela do celular
