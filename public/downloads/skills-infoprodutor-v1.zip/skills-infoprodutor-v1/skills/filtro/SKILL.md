---
name: filtro
description: Dá nota numa pauta antes de gravar, pela régua do desejo de massa (Breakthrough Advertising, Eugene Schwartz). Usar quando aparecer ideia de conteúdo, lista de pautas, calendário editorial, ou quando pedirem "vale a pena gravar isso?".
---

<!-- A FORMA (copie esta anatomia, troque o conteúdo pelo seu)
  1. description  = o gatilho. Quando a IA deve puxar isto sozinha.
  2. A cicatriz   = o erro real que te custou dinheiro ou tempo. Com número.
  3. O procedimento = os passos, na ordem, específicos o bastante para executar.
  4. As armadilhas = o que parece certo e não é. É a parte que ninguém escreve.
  5. O checklist  = como saber que terminou.
  A cicatriz aqui é minha. Troque pela sua: é ela que faz a skill valer.
-->

# Filtro

## A cicatriz

Eu gravei um vídeo sobre o meu sistema. Gostei do resultado, achei que estava
claro, e ele fez 147 views. Na mesma semana, uma peça sobre a dor de estar
ficando para trás fez trinta vezes isso, com menos produção.

O tema era sobre mim.

Você grava o que te interessa. A pessoa assiste o que **ela** já queria.
Ninguém cria um desejo: eles se formam ao longo de anos, e um criador com uma
câmera não inventa nem derruba nenhum. O trabalho é achar um que já existe e
ficar na frente dele.

Consequência prática, que decide a semana inteira de conteúdo:

**O tema define o teto. O gancho decide quanto do teto você alcança.**

Gancho bom não salva tema fraco. Ele só te dá uma fatia maior de nada.

## As 3 perguntas (nota 1 a 5 cada)

**1. Quanto dói?**
A pergunta é quão forte, e quão **agora**. Dor constante vale
muito mais que incômodo ocasional. A pessoa está sentindo isso hoje às 14h, ou
acharia interessante se tivesse um minuto livre?

**2. Volta sempre?**
Isso se resolve de vez ou reseta? Fome volta todo dia e nunca fica resolvida;
vontade de um jantar especial se satisfaz uma vez e acabou. A dor da sua pauta
volta toda segunda-feira, ou a pessoa aprende uma vez e nunca mais pensa nisso?

**3. Quanta gente tem?**
A pessoa precisa já estar fazendo alguma coisa específica para se importar, ou
basta estar viva? Nicho fundo com dor alta ainda pode ganhar de nicho largo com
dor morna, mas você tem que saber qual dos dois está comprando.

**Some as três. Corte em 12 de 15.** Abaixo disso, a pauta não morre: ela volta
para a fila e espera uma versão com mais dor.

## Como aplicar (o procedimento)

1. **Peça a lista crua.** Toda ideia que existe, sem filtro, incluindo as ruins.
2. **Escreva a dor-mestre do público, nas palavras DELE.** Uma frase, em primeira
   pessoa, do jeito que a pessoa falaria com um amigo. Sem essa frase, as notas
   viram chute. Exemplo de formato: *"eu sei que deveria estar fazendo X, e tô
   ficando pra trás enquanto gente pior que eu cresce."*
3. **Nota nas 3 perguntas, com uma linha de justificativa cada.** Nota sem
   justificativa não serve para calibrar as próximas.
4. **Veredito seco:** grava / reescreve / arquiva.
5. **Para as que ficaram entre 9 e 11, reescreva o ângulo** e pontue de novo.
   Quase sempre a pauta sobe quando você troca "o que eu quero contar" por "a dor
   que a pessoa já tem". A mesma ferramenta pode virar uma pauta de nota 8 e uma
   de nota 13, dependendo de quem lidera a frase.
6. **Regra destilada:** a pauta lidera pela dor. O seu sistema, a sua ferramenta,
   o seu método entram como **prova**, nunca como manchete.

## As armadilhas

- **Pontuar o que a ferramenta faz, não o que a pessoa ganha.** "Olha meu
  sistema" é nota baixa. "Você está perdendo venda e não sabe" é nota alta.
  Mesmo conteúdo por baixo.
- **Desejo que estava quente ano passado.** As notas têm validade. Repontue.
- **Confundir nota alta com pauta original.** Nota alta diz que tem gente
  querendo. Não diz que você tem algo novo a dizer. Se a nota é alta e você não
  tem prova própria, você vai fazer o mesmo vídeo que todo mundo.

## Formato de saída

Uma tabela: pauta | dói | volta | quantos | total | veredito. Depois, uma linha
só, dizendo qual grava primeiro e por quê.

## Checklist

- [ ] A dor-mestre está escrita em primeira pessoa, nas palavras do público
- [ ] Cada uma das 3 notas tem uma linha de justificativa
- [ ] Toda pauta entre 9 e 11 foi reescrita e repontuada
- [ ] A manchete lidera pela dor, e o seu método aparece só como prova
- [ ] A linha final diz qual grava primeiro e por quê

Base: *Breakthrough Advertising*, Eugene Schwartz, 1966. O livro é a fonte da
ideia de desejo de massa; a régua de 3 perguntas e o corte em 12 são a
aplicação prática.
