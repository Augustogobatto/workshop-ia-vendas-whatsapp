---
name: gloop
description: Loop de crítica adversarial em rodadas, com um crítico novo e cego por rodada, até o artefato parar de sangrar. Usar antes de publicar, subir, disparar ou mergear qualquer coisa que custa caro se sair errada: página de vendas, disparo para a lista, relatório com número, código em produção, capa de post importante.
---

<!-- A FORMA (copie esta anatomia, troque o conteúdo pelo seu)
  1. description  = o gatilho. Quando a IA deve puxar isto sozinha.
  2. A cicatriz   = o erro real que te custou dinheiro ou tempo. Com número.
  3. O procedimento = os passos, na ordem, específicos o bastante para executar.
  4. As armadilhas = o que parece certo e falha. Ninguém escreve essa parte.
  5. O checklist  = como saber que terminou.
  A cicatriz aqui é minha. Troque pela sua: é ela que faz a skill valer.
-->

# Gloop

## A cicatriz

Uma API minha passou por **quatro rodadas de crítica adversarial**. Nenhuma veio
limpa. A rodada que revisou o plano achou 12 defeitos. A primeira no código achou
1 bloqueador e 7 importantes. A segunda achou 1 crítico e 5. A terceira ainda
achou 1 crítico e 4.

O defeito mais grave era invisível em revisão de código, no compilador e no
build. Só apareceu **executando**: uma chave revogada continuava respondendo 200,
porque uma configuração que eu tinha escrito para desligar o cache não desligava
o cache naquele caso.

Um carrossel de tese meu, já aprovado por mim, passou pelo mesmo loop e perdeu
seis afirmações: fala atribuída a quem não disse, dois números comparados com
réguas diferentes, fonte que provava o contrário do que eu citei.

**O defeito mora onde você escreveu que estava tudo bem.**

## Quando vale

Vale quando errar custa caro e o erro é invisível de fora. Não vale em rascunho,
em exploração, nem em coisa reversível em trinta segundos. O loop custa tempo e
tokens: só paga se o defeito que ele pega custaria mais.

Sinal forte de que precisa: o trabalho foi feito por várias pessoas ou vários
agentes em paralelo. Ninguém tem o todo na cabeça, e é na costura entre as peças
que rasga.

## O ciclo

```
Rodada 0   → crítico no PLANO, antes de existir qualquer artefato
  construir
Rodada 1   → crítico no ARTEFATO, rodando ou olhando
  consertar → com prova
Rodada 2   → crítico NOVO, incluindo OS CONSERTOS
  ...
```

**A rodada 0 é a mais barata da vida.** Defeito no plano custa uma edição de
texto. O mesmo defeito depois de pronto custa refazer.

**Consertar abre porta nova.** Um conserto meu recriou o mesmo defeito um metro
adiante. Por isso a rodada seguinte precisa olhar **o conserto**, não só o resto.

### Regra de parada

Pare quando **duas rodadas seguidas voltarem sem nada crítico ou importante**, ou
no **teto de 3 rodadas** no artefato, fora a rodada 0.

Corolário que economiza dinheiro: **rodada extra só existe se a anterior achou
alguma coisa.**

## As armadilhas (as 5 regras duras)

**1. O crítico tem que rodar, não reler.** Em código: executar, abrir a rota,
consultar o banco. Em peça visual: abrir a imagem e olhar. Em relatório: refazer
a conta na fonte, não na planilha intermediária. Achado sem execução é palpite, e
se marca como palpite.

**2. Desconfie do que você escreveu para provar que está tudo bem.** Os defeitos
que sobrevivem até o fim não são o trabalho: são os artefatos de garantia. O
comentário que afirma a proteção que o código não tem. O teste que confirma a si
mesmo. O script de reversão que virou no-op. Toda rodada, mande bater comentário
contra código, teste contra realidade, documento contra comportamento.

**3. Correção sai com prova que falharia sem ela.** Desfaça a correção, rode,
mostre quebrando, reverta, cole a saída. Correção sem essa prova não conta.

**4. O crítico é cego.** Ele recebe o artefato e o contrato, nunca o relato de
quem construiu. O relato contamina: o crítico passa a procurar o que o construtor
disse que fez.

**5. Não paralelize críticos que escrevem no mesmo lugar.** Ou serialize, ou dê a
cada um um recorte que não colide, ou deixe todos somente-leitura.

## Severidade

Sem escala, todo achado vira urgente e o loop nunca fecha.

| Nível | Significa | Ação |
|---|---|---|
| **BLOQUEADOR** | não compila, não roda, não abre | conserta antes de tudo |
| **CRÍTICO** | roda mas faz a coisa errada, vaza dado, cobra errado | conserta nesta rodada |
| **IMPORTANTE** | erra numa borda real e alcançável | conserta nesta rodada |
| **MENOR** | estética, nome, documento desatualizado | anota, decide no fim |

Só bloqueador, crítico e importante contam para a regra de parada.

## O prompt do crítico (molde)

> Você é um crítico adversarial cego. Sua tarefa é **provar que está quebrado**.
> Você não construiu isto e não vai receber o relato de quem construiu. Não
> elogie, não resuma.
>
> CONTRATO: [o que a coisa tem que fazer, em uma frase]
> ARTEFATO: [caminho / URL / arquivo]
>
> Antes de qualquer achado, **execute**: [comando, URL, arquivo a abrir].
>
> Investigue especificamente: [3 a 6 perguntas afiadas, incluindo os achados da
> rodada anterior que precisam continuar fechados]
>
> Para cada achado: SEVERIDADE / O DEFEITO (uma frase) / POR QUE QUEBRA (cenário
> concreto que custa caro) / CONSERTO (específico).
> Ordene do mais grave para o menos grave. No fim, uma linha de veredito.

**A lista de foco é o que impede o loop de andar em círculo:** cada achado real
de uma rodada vira um item que a rodada seguinte tem que reconfirmar fechado.

## O veredito

Feche sempre com isto, sem enfeite:

```
RODADAS: N (achados por rodada: a, b, c)
ABERTO:  o que sobrou e por quê, com severidade
PROVA:   o que foi executado ou olhado (comando, saída, arquivo)
PARADA:  qual regra fechou o loop (2 limpas seguidas | teto de 3)
```

E lembre do que "pronto" significa: testado rodando, publicado, e verificado
depois de publicado. Gloop limpo em coisa que não foi publicada é trabalho que
morre com o disco.

## Checklist

- [ ] A rodada 0 rodou no plano, antes de existir artefato
- [ ] Todo crítico executou ou abriu o artefato, e o que não foi executado saiu
      marcado como palpite
- [ ] Cada rodada recebeu os achados da anterior como itens a reconfirmar
- [ ] Cada correção saiu com prova que falharia sem ela
- [ ] A parada foi por regra nomeada: 2 limpas seguidas, ou teto de 3
- [ ] O que ficou aberto está escrito, com severidade
