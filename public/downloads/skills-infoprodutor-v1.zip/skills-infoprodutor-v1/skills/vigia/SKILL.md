---
name: vigia
description: Constrói o vigia que grita quando a venda quebra, segmentado pela origem que você paga, e audita vigia que já existe. Usar quando pedirem "monitorar vendas", "avisar se parar de vender", "alerta de checkout", "vigia de tráfego", ou quando uma queda de venda for descoberta pelo extrato em vez de pelo alerta.
---

<!-- A FORMA (copie esta anatomia, troque o conteúdo pelo seu)
  1. description  = o gatilho. Quando a IA deve puxar isto sozinha.
  2. A cicatriz   = o erro real que te custou dinheiro ou tempo. Com número.
  3. O procedimento = os passos, na ordem, específicos o bastante para executar.
  4. As armadilhas = o que parece certo e não é. É a parte que ninguém escreve.
  5. O checklist  = como saber que terminou.
  A cicatriz aqui é minha. Troque pela sua: é ela que faz a skill valer.
-->

# Vigia

**Esta skill não vigia nada.** Ela escreve o vigia: o script, o agendamento e o
alerta, na sua máquina ou no seu servidor, contra o seu gateway. O que roda
sozinho depois é o script, não a skill. Se alguém prometer o contrário, está
vendendo guarda-noturno e entregando checklist.

## A cicatriz

Escrevi um vigia de venda que ficou verde por **34 horas seguidas** enquanto o
checkout de um lançamento tinha parado de converter para o tráfego pago. A mídia
rodando, o dinheiro saindo, e o alerta calado. A queda foi descoberta no
relatório, depois.

O vigia existia. O desenho é que estava errado, em dois lugares.

## As armadilhas

### 1. Check de zero absoluto não pega venda quebrada

O check era `venda_zero`: gritar se o dia inteiro fechar com zero venda. Como o
link do time vendia, o total nunca zerou. Verde.

**Agregar esconde o buraco. Segmentar pela origem que você paga é mais sensível.**

Os dois checks que pegam:

- **`trafego_zero`**: zero venda **com a tag do tráfego** e com gasto no dia.
  Só vale rodar se a marcação estiver viva (veja abaixo), senão rastreio quebrado
  vira falso alarme de venda parada.
- **`conversao`**: custo por venda do **dia corrente** contra a base recente
  (gatilho: 2,5× pior que a média dos 3 dias fechados). Sem olhar o dia corrente
  a notícia chega 26 horas depois, e aí o dinheiro já foi.

### 2. Check que compara valor com preço configurado vira ruído permanente

Havia um check que chamava de suspeita toda transação que não fosse múltiplo
exato do preço cadastrado. Desconto do comercial, parcelamento com juros, venda
corporativa e troca de lote caem todos ali. Ficou vermelho fixo, e alerta que
está sempre vermelho é alerta desligado.

**Regra:** o vigia relata fato observável ("a oferta X está vendendo"), nunca
julga se o preço "devia" ser outro.

### 3. Nenhuma checagem abria o checkout

Todas olhavam a landing page e viam HTTP 200. A landing estava no ar; o checkout
é que estava morto.

**O check que faltava:** extrair do HTML da landing o link real de pagamento
(`pay.hotmart.com/...?off=`, `pay.kiwify.com.br/...`, `checkout.stripe.com/...`)
e **abrir esse link**, conferindo status 200 e que a oferta esperada aparece na
página. Se a landing tem mais de um botão, conferir todos.

## Como construir (o procedimento)

1. **Pergunte antes de escrever código:** qual gateway (Hotmart / Kiwify / Eduzz /
   Stripe / Asaas), qual a tag de origem do tráfego pago, quanto se gasta por dia,
   e por onde o alerta deve chegar (Telegram, WhatsApp, e-mail, Slack).
2. **Peça a credencial de leitura pelo nome** e diga onde guardar (variável de
   ambiente, cofre, `.env` fora do git). Nunca aceite credencial colada no chat
   se houver alternativa, e nunca escreva credencial dentro do arquivo da skill.
3. **Levante a base:** média de venda e custo por venda dos últimos 7 dias
   fechados, por origem. Sem base não existe "pior que o normal".
4. **Implemente os 4 checks:** `checkout` (abre o link de pagamento),
   `trafego_zero`, `conversao`, `marcacao` (a tag está chegando nas vendas de hoje?).
5. **Agende** (cron ou timer). Se o projeto tiver as duas coisas, **varra cron E
   systemd** ao auditar: o vigia pode estar em qualquer um dos dois.
6. **Teste quebrando de verdade:** aponte o check de checkout para uma oferta
   inexistente e confirme que ele grita. Check que nunca gritou é decoração.

## Regra de silêncio

O vigia só fala quando é gritante. Nada de "tudo ok" diário: relatório de rotina
treina a pessoa a ignorar a notificação, e aí o alerta de verdade chega mudo.

- Sem achado → silêncio.
- Mesmo achado repetido → uma vez, depois cala por 72h.
- Sempre uma saída `--silenciar` para janela de manutenção.

## Checklist antes de dizer que o vigia está pronto

- [ ] O check abre o **link de pagamento**, não só a landing
- [ ] Existe pelo menos um check **segmentado pela origem que você paga**
- [ ] O check de conversão olha o **dia corrente**
- [ ] Nenhum check compara valor com preço cadastrado
- [ ] Foi testado **quebrando algo de propósito** e gritou
- [ ] O canal do alerta recebeu a mensagem de teste
- [ ] Existe silêncio por padrão e uma saída de manutenção
