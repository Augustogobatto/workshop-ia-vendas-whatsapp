# Changelog

## v1 (24/08/2026)

Primeira versão pública. Oito skills: `vigia`, `rastreio`, `decisao`,
`filtro`, `voz`, `docs-first`, `gloop`, `fim`.

A versão mais recente está sempre em https://ia.augustogobatto.com/skills
