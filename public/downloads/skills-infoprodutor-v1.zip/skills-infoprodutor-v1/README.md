# 8 skills de infoprodutor

Versão mais recente e os oito zips avulsos:
https://ia.augustogobatto.com/skills

São oito procedimentos meus, abertos, do jeito que rodam na minha máquina.

Eu abri para você copiar **a forma**. A cicatriz de cada uma é minha. Trocada
pela sua, ela vira a skill mais útil que você tem.

Augusto Gobatto (@augustogobatto)

---

## O que é uma skill

Uma pasta com um arquivo `SKILL.md` dentro. No topo, um `name` e uma
`description`. Embaixo, o procedimento escrito em português.

A diferença para um prompt salvo está em **onde ele mora**. Prompt mora no seu
bloco de notas e depende de você lembrar de colar. Skill mora no lugar onde a IA
procura, e ela abre o arquivo sozinha quando o assunto aparece.

A `description` é a parte mais difícil de escrever, porque é ela que decide se a
skill carrega. Escreva com as palavras que **você** usa quando pede a coisa. Quando não carregar sozinha, chame pelo
nome: `/gloop`, `/rastreio`.

## Instalar

### Claude Code, no projeto (é esta que fica no git, e que a próxima pessoa herda)

```bash
unzip -n skills-infoprodutor-v1.zip
mkdir -p .claude/skills
cp -rn skills-infoprodutor-v1/skills/* .claude/skills/
```

### Claude Code, só para você

```bash
mkdir -p ~/.claude/skills
cp -rn skills-infoprodutor-v1/skills/* ~/.claude/skills/
```

O `-n` do `unzip` e do `cp` **não sobrescrevem**. Se você já tem uma skill com um
desses nomes (`fim`, `voz`, `filtro` e `gloop` são nomes genéricos, então é
provável), a sua fica de pé e a minha não entra. Renomeie a minha antes de copiar.

### claude.ai

Configurações > Recursos > Skills, e suba o zip da skill que quiser. Precisa de
plano pago com execução de código ligada. Lá é um zip por skill: use os oito
avulsos que estão na página.

### Conferir que instalou

Digite `/gloop`. Se autocompletar, entrou. Depois teste o carregamento
automático pedindo *"revisa isso antes de eu publicar"*: a `gloop` tem que
aparecer sozinha.

### ChatGPT e Gemini

O conteúdo é markdown puro, então cola num Project ou numa Gem e funciona. Só
que aí quem escolhe o que entra na conversa é você.

## As oito

**Dinheiro**

| | |
|---|---|
| `vigia` | escreve o vigia que grita quando a venda quebra (a skill escreve; quem roda depois é o script) |
| `rastreio` | faz a origem da venda sobreviver da página até o checkout |
| `recorrencia` | acha a assinatura que está morrendo em silêncio |
| `vespera` | responde "estamos prontos?" com a lista do que foi rodado |

**Conteúdo**

| | |
|---|---|
| `filtro` | dá nota na pauta antes de você gravar |
| `voz` | faz a IA escrever com a sua voz, porque a sua voz está escrita |

**Método**

| | |
|---|---|
| `gloop` | crítica adversarial em rodadas, com regra de parada nomeada |
| `fim` | fecha a sessão gravando o que a IA aprendeu |

## Como trocar a cicatriz pela sua

Abra qualquer `SKILL.md`. Depois do cabeçalho tem um bloco comentado com a
anatomia: gatilho, cicatriz, procedimento, armadilhas, checklist.

1. **Ache a sua cicatriz.** Procure um episódio, com data: a vez que você perdeu
   dinheiro, tempo ou cliente por causa disso. Tema solto não serve. Se não tem
   número, ainda é opinião.
2. **Escreva o procedimento como você faria hoje**, sabendo o que sabe agora.
3. **A parte que vale mais é a das armadilhas**: o que parece certo e falha.
   Ninguém escreve essa parte, e é ela que a IA nunca adivinha.
4. **O checklist é como você sabe que terminou.** Sem ele, a IA para quando cansa.

Regra que eu sigo: quando eu explico a mesma coisa pela terceira vez, aquilo
vira skill no mesmo dia.

## Licença

MIT (arquivo `LICENSE`). Use, edite, ensine, venda o serviço que usa isto. Se
publicar uma versão modificada, não diga que é a minha.

Créditos e fontes em `CREDITOS.md`. Versão e mudanças em `CHANGELOG.md`.
