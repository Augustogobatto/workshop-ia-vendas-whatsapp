# Créditos e fontes

Todo o texto deste pack foi escrito por mim. As cicatrizes são de operações
minhas, com clientes e parceiros anonimizados de propósito: o mecanismo do erro
é o que importa, o nome de quem passou por ele não é meu para publicar.

**Ideias de terceiros que estão aqui, e de quem são:**

- A `filtro` aplica a ideia de **desejo de massa** de Eugene Schwartz,
  *Breakthrough Advertising* (1966). A régua de três perguntas com nota de 1 a 5
  e o corte em 12 de 15 são a minha aplicação prática da ideia dele. Se você
  trabalha com copy e ainda não leu o livro, leia o livro.
- O formato `SKILL.md` é da Anthropic. A especificação e as skills oficiais
  estão em `github.com/anthropics/skills`.
- Existem coleções grandes e boas de skills de marketing em inglês, abertas no
  GitHub. Elas cobrem copy, SEO, anúncio, e-mail e análise. Este pack foi para
  outro lado de propósito: a operação que sustenta a venda depois que a copy já
  está pronta.

**O que este pack não é:** não é curso, não é garantia, e não é a minha
operação inteira. É a forma, com oito exemplos preenchidos.
